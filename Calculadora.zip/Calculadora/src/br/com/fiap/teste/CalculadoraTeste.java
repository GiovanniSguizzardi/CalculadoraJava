package br.com.fiap.teste;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import br.com.fiap.Calculadora;

public class CalculadoraTeste {

	private Calculadora calc;
	
	@Before
	public void setUp() throws Exception {
		calc = new Calculadora();
	}

	@Test
	public void testeSomar() {
		int resultado = calc.somar(29,23);
		assertEquals(resultado, 52);
	}
	
	@Test
	public void testeSubtrair() {
		int resultado = calc.subtrair(29,23);
		assertEquals(resultado, 6);
	}
	
	@Test
	public void testeMultiplicar() {
		int resultado = calc.multiplicar(29,23);
		assertEquals(resultado, 667);
	}
	
	@Test
	public void testeDivisao() {
		int resultado = calc.dividir(29,23);
		assertEquals(resultado, 1.26, 0.26);
	}
}