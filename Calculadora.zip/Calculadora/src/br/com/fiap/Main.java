package br.com.fiap;

public class Main {
	public static void main(String[] args) {
		Calculadora c = new Calculadora();
		
		System.out.println(c.somar(10, 5));
		System.out.println(c.subtrair(10, 5));
		System.out.println(c.dividir(10, 5));
		System.out.println(c.multiplicar(10, 5));
	}
}